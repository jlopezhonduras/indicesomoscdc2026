-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-06-2026 a las 13:00:03
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `indice_lgtbi`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria`
--

CREATE TABLE `auditoria` (
  `id_auditoria` bigint(20) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `accion` varchar(200) NOT NULL,
  `tabla_afectada` varchar(100) DEFAULT NULL,
  `registro_id` bigint(20) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamentos`
--

CREATE TABLE `departamentos` (
  `id_departamento` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `departamentos`
--

INSERT INTO `departamentos` (`id_departamento`, `nombre`) VALUES
(1, 'Atlántida'),
(2, 'Colón'),
(3, 'Comayagua'),
(4, 'Copán'),
(5, 'Cortés'),
(6, 'Choluteca'),
(7, 'El Paraíso'),
(8, 'Francisco Morazán'),
(9, 'Gracias a Dios'),
(10, 'Intibucá'),
(11, 'Islas de la Bahía'),
(12, 'La Paz'),
(13, 'Lempira'),
(14, 'Ocotepeque'),
(15, 'Olancho'),
(16, 'Santa Bárbara'),
(17, 'Valle'),
(18, 'Yoro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encuestas`
--

CREATE TABLE `encuestas` (
  `id_encuesta` bigint(20) NOT NULL,
  `codigo` varchar(30) DEFAULT NULL,
  `id_formulario` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `fecha_inicio` datetime DEFAULT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `estado` varchar(20) DEFAULT 'BORRADOR',
  `departamento` varchar(100) DEFAULT NULL,
  `municipio` varchar(100) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `formularios`
--

CREATE TABLE `formularios` (
  `id_formulario` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `version` varchar(20) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `formularios`
--

INSERT INTO `formularios` (`id_formulario`, `nombre`, `descripcion`, `version`, `activo`, `fecha_creacion`) VALUES
(1, 'Encuesta Índice de Inclusión LGTBI+', 'Instrumento de recolección de datos', '1.0', 1, '2026-06-19 14:22:15');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipios`
--

CREATE TABLE `municipios` (
  `id_municipio` int(11) NOT NULL,
  `id_departamento` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `opciones_pregunta`
--

CREATE TABLE `opciones_pregunta` (
  `id_opcion` bigint(20) NOT NULL,
  `id_pregunta` bigint(20) NOT NULL,
  `valor` varchar(100) DEFAULT NULL,
  `etiqueta` varchar(255) DEFAULT NULL,
  `orden` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `opciones_pregunta`
--

INSERT INTO `opciones_pregunta` (`id_opcion`, `id_pregunta`, `valor`, `etiqueta`, `orden`) VALUES
(1, 76, 'SI', 'Sí', 1),
(2, 76, 'NO', 'No', 2),
(3, 76, 'NS', 'No sabe', 3),
(4, 76, 'NR', 'No quiere responder', 4),
(5, 76, 'NA', 'No aplica', 5),
(8, 84, 'SI', 'Sí', 1),
(9, 84, 'NO', 'No', 2),
(10, 84, 'NS', 'No sabe', 3),
(11, 84, 'NR', 'No quiere responder', 4),
(12, 84, 'NA', 'No aplica', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `opciones_respuesta`
--

CREATE TABLE `opciones_respuesta` (
  `id_opcion` bigint(20) NOT NULL,
  `id_pregunta` bigint(20) NOT NULL,
  `valor` varchar(100) DEFAULT NULL,
  `etiqueta` varchar(255) DEFAULT NULL,
  `orden` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `preguntas`
--

CREATE TABLE `preguntas` (
  `id_pregunta` bigint(20) NOT NULL,
  `id_seccion` int(11) NOT NULL,
  `pregunta` text NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `obligatoria` tinyint(1) DEFAULT 1,
  `orden` int(11) NOT NULL,
  `activa` tinyint(1) DEFAULT 1,
  `catalogo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `preguntas`
--

INSERT INTO `preguntas` (`id_pregunta`, `id_seccion`, `pregunta`, `tipo`, `obligatoria`, `orden`, `activa`, `catalogo`) VALUES
(76, 33, '¿Pertenece a alguna Organización?', 'select', 1, 1, 1, NULL),
(77, 33, 'Nombre de la Organización a la que pertenece', 'text', 1, 2, 1, NULL),
(78, 33, '¿Cuál es su sexo biológico?', 'select', 1, 3, 1, NULL),
(79, 33, 'Edad: Rango de edad de la persona', 'number', 1, 4, 1, NULL),
(80, 33, 'Según su orientación sexual usted se considera:', 'select', 1, 5, 1, NULL),
(81, 33, 'Según su identidad de género, usted se considera:', 'select', 1, 6, 1, NULL),
(82, 33, '¿En qué departamento vive actualmente?', 'select', 1, 7, 1, NULL),
(83, 34, '¿Cuál fue el último nivel de educación formal que completó?', 'select', 1, 8, 1, NULL),
(84, 34, '¿Se encuentra estudiando actualmente?', 'select', 1, 9, 1, NULL),
(85, 34, '¿Estudia en el sistema de educación formal o educación no formal?', 'select', 1, 10, 1, NULL),
(86, 34, '¿Qué grado de estudio formal se encuentra cursando actualmente?', 'number', 1, 11, 1, NULL),
(87, 34, '¿Mencione la disciplina, profesión u oficio que está estudiando?', 'textarea', 1, 12, 1, NULL),
(88, 34, '¿Ha enfrentado acoso, discriminación o violencia en el sistema educativo formal?', 'select', 1, 13, 1, NULL),
(89, 34, '¿Qué tipo de acoso, discriminación o violencia ha enfrentado en el sistema educativo?', 'textarea', 1, 14, 1, NULL),
(90, 34, 'El acoso, discriminación o violencia ha sido por parte de:', 'checkbox', 1, 15, 1, NULL),
(91, 34, '¿Tuvo la oportunidad de denunciar el acoso o discriminación vivido?', 'select', 1, 16, 1, NULL),
(92, 34, '¿Cuál fue el resultado de su denuncia?', 'textarea', 1, 17, 1, NULL),
(93, 34, '¿Por qué no lo hizo?', 'textarea', 1, 18, 1, NULL),
(94, 35, '¿Votó en las últimas elecciones primarias o generales?', 'select', 1, 19, 1, NULL),
(95, 35, '¿Por qué no votó?', 'textarea', 1, 20, 1, NULL),
(96, 35, '¿Va a votar en las próximas elecciones?', 'select', 1, 21, 1, NULL),
(97, 35, '¿Por qué sí o por qué no?', 'textarea', 1, 22, 1, NULL),
(98, 35, 'Como persona LGTBIQ+ ¿se siente aceptada por la sociedad hondureña?', 'likert', 1, 23, 1, NULL),
(99, 36, '¿Cuenta actualmente con un trabajo?', 'select', 1, 24, 1, NULL),
(100, 36, '¿Cuál es su trabajo?', 'textarea', 1, 25, 1, NULL),
(101, 36, '¿Ha sufrido discriminación en el empleo?', 'select', 1, 26, 1, NULL),
(102, 36, '¿Qué tipo de discriminación ha sufrido en el empleo?', 'textarea', 1, 27, 1, NULL),
(103, 36, '¿Se encuentra usted en situación de pobreza?', 'select', 1, 28, 1, NULL),
(104, 36, '¿Es usted dueño/a de alguna empresa?', 'select', 1, 29, 1, NULL),
(105, 36, '¿Qué actividad económica realiza su empresa?', 'textarea', 1, 30, 1, NULL),
(106, 37, '¿Ha enfrentado violencia o discriminación en razón de su orientación sexual, identidad o expresión de género en el sistema de salud hondureño?', 'select', 1, 31, 1, NULL),
(107, 37, '¿Qué tipo de violencia o discriminación ha enfrentado en el sistema de salud?', 'textarea', 1, 32, 1, NULL),
(108, 37, '¿Cuenta con una fuente específica de atención médica permanente?', 'select', 1, 33, 1, NULL),
(109, 37, '¿Cuál es esa fuente de atención médica permanente?', 'textarea', 1, 34, 1, NULL),
(110, 37, 'En caso que usted tenga útero ¿Se ha realizado estudios para detectar cáncer en el cuello uterino?', 'select', 1, 35, 1, NULL),
(111, 37, '¿Cuál fue la razón por la que se realizó este estudio?', 'textarea', 1, 36, 1, NULL),
(112, 37, '¿Es usted una persona con VIH?', 'select', 1, 37, 1, NULL),
(113, 37, '¿Ha recibido atención médica reproductiva en el sistema de salud pública?', 'select', 1, 38, 1, NULL),
(114, 37, '¿Esta atención tuvo en cuenta su orientación sexual e identidad de género?', 'select', 1, 39, 1, NULL),
(115, 37, '¿Por qué no?', 'textarea', 1, 40, 1, NULL),
(116, 38, '¿Ha asistido a recibir atención psicológica en los últimos 12 meses?', 'select', 1, 41, 1, NULL),
(117, 38, '¿Dónde recibió esa atención?', 'textarea', 1, 42, 1, NULL),
(118, 38, '¿Por qué no ha recibido esta asistencia?', 'textarea', 1, 43, 1, NULL),
(119, 38, '¿Ha padecido algún cuadro de depresión en los últimos 12 meses?', 'select', 1, 44, 1, NULL),
(120, 38, 'En general ¿Cómo se encuentra su salud?', 'likert', 1, 45, 1, NULL),
(121, 39, '¿Ha sido víctima de violencia basada en su orientación sexual, identidad o expresión de género en los últimos 12 meses?', 'select', 1, 46, 1, NULL),
(122, 39, '¿Qué tipo de violencia ha enfrentado?', 'textarea', 1, 47, 1, NULL),
(123, 39, '¿Qué tanto confía en que el sistema judicial hondureño ante la violencia que viven las personas LGTBIQ+?', 'likert', 1, 48, 1, NULL),
(124, 39, '¿Ha sido detenido/a en alguna ocasión por las fuerzas de seguridad?', 'select', 1, 49, 1, NULL),
(125, 39, '¿Cuál fue la causa de dicha detención?', 'textarea', 1, 50, 1, NULL),
(126, 39, 'Durante su detención ¿Fue víctima de discriminación o violencia?', 'select', 1, 51, 1, NULL),
(127, 39, '¿Qué tipo de violencia o discriminación sufrió durante su detención?', 'textarea', 1, 52, 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas`
--

CREATE TABLE `respuestas` (
  `id_respuesta` bigint(20) NOT NULL,
  `id_encuesta` bigint(20) NOT NULL,
  `id_pregunta` bigint(20) NOT NULL,
  `respuesta_texto` longtext DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_rol`, `nombre`, `descripcion`, `activo`, `fecha_creacion`) VALUES
(1, 'ADMIN', 'Administrador General', 1, '2026-06-18 15:08:29'),
(2, 'RECOLECTOR', 'Ingreso de encuestas', 1, '2026-06-18 15:08:29'),
(3, 'CONSULTA', 'Consulta de reportes', 1, '2026-06-18 15:08:29'),
(4, 'DESCARGA', 'Consulta y descarga de base de datos', 1, '2026-06-18 15:08:29');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `secciones`
--

CREATE TABLE `secciones` (
  `id_seccion` int(11) NOT NULL,
  `id_formulario` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `orden` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `secciones`
--

INSERT INTO `secciones` (`id_seccion`, `id_formulario`, `nombre`, `orden`) VALUES
(33, 1, 'Datos Generales', 1),
(34, 1, 'Educación', 2),
(35, 1, 'Participación Ciudadana', 3),
(36, 1, 'Empleo y Economía', 4),
(37, 1, 'Salud', 5),
(38, 1, 'Salud Mental', 6),
(39, 1, 'Violencia y Justicia', 7),
(40, 1, 'Resumen', 8);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sesiones`
--

CREATE TABLE `sesiones` (
  `id_sesion` bigint(20) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `ip` varchar(50) DEFAULT NULL,
  `navegador` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `correo` varchar(150) DEFAULT NULL,
  `nombres` varchar(150) NOT NULL,
  `apellidos` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `id_rol` int(11) NOT NULL,
  `ultimo_acceso` datetime DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `creado_por` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `usuario`, `correo`, `nombres`, `apellidos`, `password_hash`, `id_rol`, `ultimo_acceso`, `activo`, `fecha_creacion`, `creado_por`) VALUES
(1, 'admin', 'admin@indicesomos.org', 'Administrador', 'Sistema', '$2a$12$LF.UZUNV4DYgMun9gr59b.LGzM48EW/Ztj/jrr5SmRed4Az0lZfWe', 1, NULL, 1, '2026-06-18 15:10:35', NULL),
(2, 'jlopez', 'jalf2001@hotmail.com', 'Jorge', 'Lopez', '$2y$10$LHPnzbtozomLhNe61UCiM.UT/KmL/UMrYJQ7RMCB/EGRKc8oBikbe', 2, NULL, 1, '2026-06-18 20:01:12', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_formulario`
--

CREATE TABLE `usuario_formulario` (
  `id_usuario_formulario` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_formulario` int(11) NOT NULL,
  `fecha_asignacion` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  ADD PRIMARY KEY (`id_auditoria`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `departamentos`
--
ALTER TABLE `departamentos`
  ADD PRIMARY KEY (`id_departamento`);

--
-- Indices de la tabla `encuestas`
--
ALTER TABLE `encuestas`
  ADD PRIMARY KEY (`id_encuesta`),
  ADD UNIQUE KEY `codigo` (`codigo`),
  ADD KEY `id_formulario` (`id_formulario`),
  ADD KEY `idx_encuesta_usuario` (`id_usuario`);

--
-- Indices de la tabla `formularios`
--
ALTER TABLE `formularios`
  ADD PRIMARY KEY (`id_formulario`);

--
-- Indices de la tabla `municipios`
--
ALTER TABLE `municipios`
  ADD PRIMARY KEY (`id_municipio`),
  ADD KEY `id_departamento` (`id_departamento`);

--
-- Indices de la tabla `opciones_pregunta`
--
ALTER TABLE `opciones_pregunta`
  ADD PRIMARY KEY (`id_opcion`),
  ADD KEY `id_pregunta` (`id_pregunta`);

--
-- Indices de la tabla `opciones_respuesta`
--
ALTER TABLE `opciones_respuesta`
  ADD PRIMARY KEY (`id_opcion`),
  ADD KEY `id_pregunta` (`id_pregunta`);

--
-- Indices de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD PRIMARY KEY (`id_pregunta`),
  ADD KEY `idx_pregunta_seccion` (`id_seccion`);

--
-- Indices de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD PRIMARY KEY (`id_respuesta`),
  ADD KEY `idx_respuesta_encuesta` (`id_encuesta`),
  ADD KEY `idx_respuesta_pregunta` (`id_pregunta`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_rol`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `secciones`
--
ALTER TABLE `secciones`
  ADD PRIMARY KEY (`id_seccion`),
  ADD KEY `id_formulario` (`id_formulario`);

--
-- Indices de la tabla `sesiones`
--
ALTER TABLE `sesiones`
  ADD PRIMARY KEY (`id_sesion`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `usuario` (`usuario`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD KEY `id_rol` (`id_rol`),
  ADD KEY `creado_por` (`creado_por`);

--
-- Indices de la tabla `usuario_formulario`
--
ALTER TABLE `usuario_formulario`
  ADD PRIMARY KEY (`id_usuario_formulario`),
  ADD UNIQUE KEY `id_usuario` (`id_usuario`,`id_formulario`),
  ADD KEY `id_formulario` (`id_formulario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  MODIFY `id_auditoria` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `departamentos`
--
ALTER TABLE `departamentos`
  MODIFY `id_departamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `encuestas`
--
ALTER TABLE `encuestas`
  MODIFY `id_encuesta` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `formularios`
--
ALTER TABLE `formularios`
  MODIFY `id_formulario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `municipios`
--
ALTER TABLE `municipios`
  MODIFY `id_municipio` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `opciones_pregunta`
--
ALTER TABLE `opciones_pregunta`
  MODIFY `id_opcion` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `opciones_respuesta`
--
ALTER TABLE `opciones_respuesta`
  MODIFY `id_opcion` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `preguntas`
--
ALTER TABLE `preguntas`
  MODIFY `id_pregunta` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  MODIFY `id_respuesta` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `secciones`
--
ALTER TABLE `secciones`
  MODIFY `id_seccion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT de la tabla `sesiones`
--
ALTER TABLE `sesiones`
  MODIFY `id_sesion` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario_formulario`
--
ALTER TABLE `usuario_formulario`
  MODIFY `id_usuario_formulario` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `auditoria`
--
ALTER TABLE `auditoria`
  ADD CONSTRAINT `auditoria_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `encuestas`
--
ALTER TABLE `encuestas`
  ADD CONSTRAINT `encuestas_ibfk_1` FOREIGN KEY (`id_formulario`) REFERENCES `formularios` (`id_formulario`),
  ADD CONSTRAINT `encuestas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `municipios`
--
ALTER TABLE `municipios`
  ADD CONSTRAINT `municipios_ibfk_1` FOREIGN KEY (`id_departamento`) REFERENCES `departamentos` (`id_departamento`);

--
-- Filtros para la tabla `opciones_pregunta`
--
ALTER TABLE `opciones_pregunta`
  ADD CONSTRAINT `opciones_pregunta_ibfk_1` FOREIGN KEY (`id_pregunta`) REFERENCES `preguntas` (`id_pregunta`);

--
-- Filtros para la tabla `opciones_respuesta`
--
ALTER TABLE `opciones_respuesta`
  ADD CONSTRAINT `opciones_respuesta_ibfk_1` FOREIGN KEY (`id_pregunta`) REFERENCES `preguntas` (`id_pregunta`);

--
-- Filtros para la tabla `preguntas`
--
ALTER TABLE `preguntas`
  ADD CONSTRAINT `preguntas_ibfk_1` FOREIGN KEY (`id_seccion`) REFERENCES `secciones` (`id_seccion`);

--
-- Filtros para la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD CONSTRAINT `respuestas_ibfk_1` FOREIGN KEY (`id_encuesta`) REFERENCES `encuestas` (`id_encuesta`),
  ADD CONSTRAINT `respuestas_ibfk_2` FOREIGN KEY (`id_pregunta`) REFERENCES `preguntas` (`id_pregunta`);

--
-- Filtros para la tabla `secciones`
--
ALTER TABLE `secciones`
  ADD CONSTRAINT `secciones_ibfk_1` FOREIGN KEY (`id_formulario`) REFERENCES `formularios` (`id_formulario`);

--
-- Filtros para la tabla `sesiones`
--
ALTER TABLE `sesiones`
  ADD CONSTRAINT `sesiones_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`),
  ADD CONSTRAINT `usuarios_ibfk_2` FOREIGN KEY (`creado_por`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `usuario_formulario`
--
ALTER TABLE `usuario_formulario`
  ADD CONSTRAINT `usuario_formulario_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `usuario_formulario_ibfk_2` FOREIGN KEY (`id_formulario`) REFERENCES `formularios` (`id_formulario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
